const SocketState =  {
    IN_LOGIN:0,
    IN_GAME:1
}

module.exports = SocketState;